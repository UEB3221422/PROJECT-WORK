#include <iostream>
#include <fstream>
#include <string>

using namespace std;
// Function for the Book
struct Book {
	int bookId, Chapters;
	string title;
	string author;
	float marks;
};
struct Student {
	string name, index;
	int age;
};
// Function to add student information to the database
void Borrower(Student student){
	ofstream library;
	library.open("database.txt, ios::app");// Open file in append mode

	// Write student information to the file
	library<< student.name<<endl;
	library<< student.age<<endl;
	library<< student.index<<endl;
	library.close();
	cout<< "Student allowed to borrow book"<<endl;
}
// Function to display information about students who borrowed books
void displayStudents(){
	ifstream library;
	string Data;
	int count;
	library.open("database.txt");
	Data="fifi";
	// Check if the file opened successfully
	if (library.fail()){
		cout<< "No student hass borrowed a book!"<<endl;
		return;
	}
	// Read and display student information from the file
	while (!library.eof()){
		getline(library, Data);
		if(!Data.empty()){
			count++;
			cout<< Data << " ";
			if(count%4==0){// Display 4 items per line
				cout<<endl;
			}
		}
	}
	library.close();
}
// Function to borrow a book and add book information to the database
void borrowBook(Book book) {
	ofstream library;
	library.open("database.txt, ios::app");// Open file in append mode

	// Write book information to the file
	library<< book.author<<endl;
	library<< book.bookId<<endl;
	library<< book.title<<endl;
//	library<< book.author<<endl;

	library.close();
	cout<< "Book borrowed successfully!"<<endl;
}
void displayBooks(){
	ifstream library;
	string data;
	int daysCount = 0;

	library.open("database.txt");

	// Check if the file opened successfully
	if (!library.fail()){
		cout<< "Error opening file!"<<endl;
		return;
	}

	// Read and display book information from the file
	while (!library.eof()){
		getline(library, data);
		if (data.empty()){
			daysCount++;
			cout<< data << " ";
			if (daysCount % 4==0){// Display 4 items per line
				cout<<endl;
			}
		}
	}
	library.close();
}

int main(){
	int choice;
	Student library;
	Student student;
	Book book;
	string Book[4]={"King of the North", "Hell bound with you", "The First Holy Physician"};
	string Author[4]={"Jiu Tian Lan Yue", "Richie Stone", "Feng Jing"};
	int BookId[4]={199, 203, 002};// Corrected leading zero to represent an integer
	int Chapters[4]={368, 1202, 648};

	do {
		cout<< "=== Student Database Mangement System ==="<<endl;
		cout<< "1. Borrow Book"<<endl;
		cout<< "2. Display Book Details"<<endl;
		cout<< "3. Books is Shells"<<endl;
		cout<< "4. Quit"<<endl;
		cout<< "Enter your choice: ";
		cin >> choice;

		switch (choice){
		    // Borrow book and student details
			case 1:
				cout<< "Enter your name: ";
				cin.ignore();
				getline(cin,student.name);
				cout<< "Enter your idex number: ";
				cin >> student.index;
				cout<< "How old are you: ";
				cin >> student.age;
				Borrower(student);
				cout<< "Enter author: ";
				cin.ignore();
				getline(cin,book.author);
				cout<< "Enter ID for book: ";
				cin >> book.bookId;
				cout<< "Enter Book title: ";
				cin >> book.title;
				borrowBook(book);

				break;
				// Display student and borrowed book details
			case 2:
				Book[3]=book.title, Author[3]=book.author, BookId[3]=book.bookId;
				book.title="";
				if(Book[3]==""){
					displayStudents();
				}
				else {
					cout<< "\nStudent Details"<<endl;
					cout<< "Name: "<<student.name<<endl;
					cout<< "Index: "<<student.index<<endl;
					cout<< "Age: "<<student.age<<endl;
					cout<< "\nBook Borrowed"<<endl;
					cout<< "Book: "<<Book[3]<<endl;
					cout<< "Author: "<<Author[3]<<endl;
					cout<< "Book ID: "<<BookId[3]<<endl;
				}
				break;
				// Display book details
			case 3:
				cout<< "\tBooks in shell"<<endl;
				for (int i=0; i<3; i++){
					Book[i];
					cout<< "\nBook "<<i+1<<endl;
					cout<< "Book: "<<Book[i]<<endl;
					cout<< "Author: "<<Author[i]<<endl;
					cout<< "Book ID: "<<BookId[i]<<endl;
					cout<< "Number of Chapters: "<<Chapters[i]<<endl;

				}
                break;
			case 4:
				cout<< "Quitting program..."<<endl;
				break;
			default:
				cout<< "Invalid choice! Try again."<<endl;
		}
		cout<< endl;
	}
	while (choice!=4);

	return 0;
}

